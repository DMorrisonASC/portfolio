## Space_Defender

### Description
A spin-off of Space-Invaders: A fixed shooter in which the player controls a laser cannon by moving it across the screen and firing at descending aliens. The player earns points by destroying enemies with it's projectiles.
If the player collides with enemies or their projectiles then game over.
Goal: Survive as long as possible and earn as much points by defeating enemies.

### SpaceDefender Gameplay Walk-though

<img src="https://i.imgur.com/Upc8lPq.gif" width=200><br>

### Extract Zip to Use it!!!

